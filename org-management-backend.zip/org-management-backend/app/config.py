
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    MONGO_URI: str
    MASTER_DB: str = "master_db"
    JWT_SECRET: str
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440  # 1 day

    class Config:
        env_file = ".env"  # yahi se values read karega

settings = Settings()
